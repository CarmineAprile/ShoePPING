package com.example.shoepping.use_case.edit_profile.controller;

import com.example.shoepping.EditProfileGController;
import com.example.shoepping.use_case.edit_profile.view.IEditProfileView;

public class EditProfileController implements IEditProfileController{

    IEditProfileView editProfileView;

    public EditProfileController(IEditProfileView profileView){
        
    }
    @Override
    public void onEditProfile(String username, String pass, String repass, String email, String oldUsername, boolean check) {

    }
}
