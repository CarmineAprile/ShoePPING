package org.main;

public class Palindroma {

    public static boolean calculatePalindroma(String string){
        int len = string.length();

        for(int i=0; i<((len-1)/2); i++){
            if(string.charAt(i) != string.charAt(len-i-1))
                return false;
        }

        return true;
    }
}