package org.main;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.main.CalculateLength.calculateLength;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestCalculateLength {
    @ParameterizedTest
    @CsvSource({
            "prova, 5",
            "'', 0",
            "' ', 1",
            //", 0" se si usa il metodo sulla stringa null, cè un bug che però non è stato visto nel test
    })
    void TestCalculateLength(String string, int expectedValue){
        int output = calculateLength(string);
        assertEquals(expectedValue, output, 0);
    }
}