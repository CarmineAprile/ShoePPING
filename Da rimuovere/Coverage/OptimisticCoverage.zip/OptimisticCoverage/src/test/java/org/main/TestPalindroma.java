package org.main;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.main.Palindroma.calculatePalindroma;

public class TestPalindroma {
    @ParameterizedTest
    @CsvSource({
            "prova, false",
            "afa, true",
            // "Afa, true", il test va male con stringhe che non sono palindrome anche dal punto di vista delle maiuscole (afA anche non risulterebbe palindroma)
    })
    void TestCalculateLength(String string, boolean expectedValue){
        boolean output = calculatePalindroma(string);
        assertEquals(expectedValue, output);
    }
}
