package org.example;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestFuelIsEnough {
    @ParameterizedTest
    @CsvSource({
            "true",
            "false",
            //"true",
            //"true",
    })
    void TestFuelIsEnough(boolean expectedValue){
        Car car = new Car();

        FuelIsEnough fuelIsEnough = new FuelIsEnough();

        boolean distanceCovered = fuelIsEnough.fuelIsEnough(car);

        assertEquals(expectedValue, distanceCovered);
    }
}