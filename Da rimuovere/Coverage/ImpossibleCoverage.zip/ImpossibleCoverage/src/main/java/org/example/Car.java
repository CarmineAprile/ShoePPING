package org.example;

import java.util.Random;

public class Car {

    private final Model model;
    private final int fuel;

    public Car(){
        Random r = new Random();
        this.fuel = r.nextInt(60);

        int nModels = Model.values().length;

        if(nModels!=0){
            this.model = Model.values()[r.nextInt(nModels)];
        }else
            this.model = null;
    }


    public Model getModel() {
        return model;
    }

    public int getFuel() {
        return fuel;
    }
}