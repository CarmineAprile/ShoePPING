package org.example;

public class FuelIsEnough {

    public boolean fuelIsEnough(Car car){

        Model model = car.getModel();
        int fuel = car.getFuel();

        int kilometers = 0;

        switch (model){
            case Suv -> kilometers = fuel * 16;
            case Micro -> kilometers = fuel * 18;
            case Supercar -> kilometers = fuel * 6;
            case Sedan -> kilometers = fuel * 17;
        }

        if(kilometers <= 100){
            return false;
        }else return true;
    }
}
