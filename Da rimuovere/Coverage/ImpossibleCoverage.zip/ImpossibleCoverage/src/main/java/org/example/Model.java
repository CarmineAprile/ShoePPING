package org.example;

public enum Model {
    Suv, Micro, Supercar, Sedan
}
