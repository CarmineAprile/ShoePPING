package org.main;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.main.CalculateWhitespaces.calculateWhitespaces;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestCalculateWhitespaces {
    @ParameterizedTest
    @CsvSource({
            "ciao come stai, 2",
            "tutto  bene?, 1",
            "il sole splende come non ha mai splenduto, 7",
    })
    void TestCalculateWhitespaces(String string, int expectedValue){
        int output = calculateWhitespaces(string);
        assertEquals(expectedValue, output, 0);
    }
}
