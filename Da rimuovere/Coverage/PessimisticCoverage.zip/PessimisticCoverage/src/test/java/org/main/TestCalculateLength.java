package org.main;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.main.CalculateLength.calculateLength;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestCalculateLength {
    @ParameterizedTest
    @CsvSource({
            "prova, 5",
            "questa è un altra  prova, 23",
            "test, 4",
    })
    void TestCalculateLength(String string, int expectedValue){
        int output = calculateLength(string);
        assertEquals(expectedValue, output, 0);
    }
}