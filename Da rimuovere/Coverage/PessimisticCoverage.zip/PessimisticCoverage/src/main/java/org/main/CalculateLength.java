package org.main;

public class CalculateLength {

    public static int calculateLength(String string){
        int counter = 0;

        for(char c : string.toCharArray()){
            counter++;
        }


        return counter;
    }
}
