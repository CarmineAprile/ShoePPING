package org.main;

public class CalculateWhitespaces {
    public static int calculateWhitespaces(String string){
        int len = string.length();
        int counter = 0;

        for(int i = 0; i<len; i++){
            if(string.charAt(i) == ' ')
                counter++;
        }

        return counter;
    }
}
