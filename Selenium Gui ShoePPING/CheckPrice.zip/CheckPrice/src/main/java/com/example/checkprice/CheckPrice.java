package com.example.checkprice;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

// page_url = https://www.jetbrains.com/
public class CheckPrice {

    public static void main(String[] args) {

        CheckPrice mainPage = new CheckPrice();
        mainPage.checkPrice();
    }

    public String checkPrice() {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\utente\\Desktop\\CheckPrice\\driver\\chromedriver.exe");

        ChromeOptions options = new ChromeOptions();
        options.addArguments("--remote-allow-origins=*");

        WebDriver driver = new ChromeDriver(options);
        // ingrandisce la schermata
        driver.manage().window().maximize();
        driver.get("https://www.newbalance.it/it?cq_src=google_ads&cq_cmp=19614965000&cq_con=145968750456&cq_term=new%20balance&cq_net=g&cq_plt=gp&gclid=Cj0KCQjw1rqkBhCTARIsAAHz7K0ouV7_VOS6PQYEaPNzyHeHcN-ahgl4GUKOAJX1OvolJpV6vzMwHLcaArNYEALw_wcB&gclsrc=aw.ds");

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        driver.findElement(By.xpath("/html/body/div[6]/div[2]/div[2]/button[2]")).click();

        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        driver.findElement(By.xpath("/html/body/div[2]/header/div/nav/div[1]/div/div[2]/div/div/nav/div[2]/ul/li[2]/a")).click();
        String price = driver.findElement(By.xpath("/html/body/div[2]/div[1]/div[3]/div/div/div[1]/div/div[4]/div[6]/div[2]/div/div/div[2]/div[1]/div[2]/div/span/span")).getText();

        try {
            Thread.sleep(7000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        System.out.println(price);

        // chiude la schermata
        driver.close();

        return price;
    }

}
