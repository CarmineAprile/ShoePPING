package com.example.testcheckprice;

import com.example.checkprice.CheckPrice;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestCheckPrice {

    //Carmine Aprile
    @Test
    public void TestPrice(){
        CheckPrice mainPage = new CheckPrice();
        String result = mainPage.checkPrice();

        assertEquals(result, "€150,00");
    }

}
