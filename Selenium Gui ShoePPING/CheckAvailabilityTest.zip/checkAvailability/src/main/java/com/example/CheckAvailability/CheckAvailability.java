package com.example.CheckAvailability;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

// page_url = https://www.jetbrains.com/
public class CheckAvailability {

    public static void main(String[] args) {

        CheckAvailability mainPage = new CheckAvailability();
        mainPage.checkAvailability();
    }

    public String checkAvailability() {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\utente\\Desktop\\checkAvailability\\driver\\chromedriver.exe");

        ChromeOptions options = new ChromeOptions();
        options.addArguments("--remote-allow-origins=*");

        WebDriver driver = new ChromeDriver(options);
        // ingrandisce la schermata
        driver.manage().window().maximize();
        driver.get("https://www.amazon.it/?&tag=goitab-21&ref=pd_sl_781ozcfkw6_e&adgrpid=53314799220&hvpone=&hvptwo=&hvadid=279876255496&hvpos=&hvnetw=g&hvrand=16974269616724876156&hvqmt=e&hvdev=c&hvdvcmdl=&hvlocint=&hvlocphy=9050591&hvtargid=kwd-10573980&hydadcr=10841_1711180");

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        driver.findElement(By.xpath("/html/body/div[1]/span/form/div[3]/span[1]/span/input")).click();

        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        driver.findElement(By.xpath("/html/body/div[1]/header/div/div[4]/div[2]/div[2]/div/a[9]")).click();

        driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[2]/div/div/div[2]/ul/li[4]")).click();

        driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[2]/div/div/div[2]/ul/li[4]/span/a")).click();

        driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[1]/div[1]/div/span[1]/div[1]/div[3]/div/div/div/div/div/div[1]/div/div[2]/div/span/a")).click();

        String availability = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[5]/div[4]/div[1]/div[3]/div/div/div/div[1]/div/div/div/form/div/div/div/div/div[3]/div/div[4]/div/div[1]/span")).getText();

        try {
            Thread.sleep(7000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        // chiude la schermata
        driver.close();

        return availability;
    }

}
