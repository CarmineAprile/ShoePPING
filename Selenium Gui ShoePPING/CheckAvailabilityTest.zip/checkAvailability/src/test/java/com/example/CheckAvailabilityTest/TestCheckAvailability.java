package com.example.CheckAvailabilityTest;

import com.example.CheckAvailability.CheckAvailability;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestCheckAvailability {

    //Daniele Ausili
    @Test
    public void TestAvailability(){
        CheckAvailability mainPage = new CheckAvailability();
        String result = mainPage.checkAvailability();

        assertEquals(result, "Disponibilità immediata");
    }
}
