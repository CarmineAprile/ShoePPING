package com.example.shoepping.model.order;

public interface IOrderList {

    void addOrder(Order order);
}
