package com.example.shoepping.pattern.observer;

public interface ISizeAmount {

    int getShoeSize();
    int getShoeAmount();
}
