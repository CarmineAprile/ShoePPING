package com.example.shoepping.dao.catalog_dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

public interface ICatalogDao {
    ArrayList<String> getCatalog() throws SQLException, IOException, ClassNotFoundException;
}
