package com.example.shoepping.second_interface;


public class ShoeppingCLILauncher {
    public static void main(String[] args) throws Exception {
        LoginCLIController loginCLIController = new LoginCLIController();
        loginCLIController.start();
    }
}
