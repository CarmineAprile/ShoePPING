package com.example.shoepping.bean;

public class SellerBean {
    private String seller;

    public SellerBean() {
        // empty constructor
    }

    public String getSeller() {
        return seller;
    }

    public void setSeller(String seller) {
        this.seller = seller;
    }
}
