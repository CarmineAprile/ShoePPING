package com.example.shoepping.bean;

public class MessageBean {
    private String message;

    public MessageBean() {
        // empty constructor
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
