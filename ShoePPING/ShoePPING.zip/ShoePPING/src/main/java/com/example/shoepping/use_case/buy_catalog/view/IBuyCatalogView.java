package com.example.shoepping.use_case.buy_catalog.view;

public interface IBuyCatalogView {
    void setShoeLabel(String item);

    void onApplyFilterError();
}
