package com.example.shoepping.use_case.buy_shoe.view;

public interface IBuyShoeView {
    void onDisable(int i);
}
