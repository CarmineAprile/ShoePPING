package com.example.shoepping.use_case.administrator.controller;

public interface IAdministratorController {
}
