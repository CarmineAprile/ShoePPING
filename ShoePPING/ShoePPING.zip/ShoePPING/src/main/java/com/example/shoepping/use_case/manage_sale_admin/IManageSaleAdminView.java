package com.example.shoepping.use_case.manage_sale_admin;

import java.util.List;

public interface IManageSaleAdminView {
    void setSaleButton(String s, List<String> itemData);
}
