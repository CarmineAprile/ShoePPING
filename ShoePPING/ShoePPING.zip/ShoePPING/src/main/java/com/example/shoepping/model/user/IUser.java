package com.example.shoepping.model.user;

public interface IUser {

    String getUsername();
    String getPassword();
    String getEmail();
    void setUsername(String username);
    void setPassword(String password);
    void setEmail(String email);
}
