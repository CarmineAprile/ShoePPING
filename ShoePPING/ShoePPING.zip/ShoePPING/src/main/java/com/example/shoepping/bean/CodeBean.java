package com.example.shoepping.bean;

public class CodeBean {
    private int code;

    public CodeBean() {
        // empty constructor
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }
}
