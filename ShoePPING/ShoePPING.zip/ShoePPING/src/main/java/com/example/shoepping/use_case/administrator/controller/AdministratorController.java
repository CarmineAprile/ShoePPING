package com.example.shoepping.use_case.administrator.controller;

public class AdministratorController implements IAdministratorController{
}
