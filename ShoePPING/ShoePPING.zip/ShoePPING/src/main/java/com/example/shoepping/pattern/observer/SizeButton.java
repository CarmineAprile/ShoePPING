package com.example.shoepping.pattern.observer;

public interface SizeButton {
    void update();

    boolean getIsAvailable();
}
