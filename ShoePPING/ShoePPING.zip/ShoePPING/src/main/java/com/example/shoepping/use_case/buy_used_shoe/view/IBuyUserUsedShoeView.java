package com.example.shoepping.use_case.buy_used_shoe.view;

public interface IBuyUserUsedShoeView {
    void setShoeLabel(String item);
}
