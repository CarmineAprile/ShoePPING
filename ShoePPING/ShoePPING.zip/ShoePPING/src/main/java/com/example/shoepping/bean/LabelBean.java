package com.example.shoepping.bean;

public class LabelBean {
    private String label;

    public LabelBean() {
        // empty constructor
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }
}
