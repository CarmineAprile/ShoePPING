package com.example.shoepping.use_case.buy_user;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

public interface IBuyUserController {

    String[] onNikeList() throws SQLException, IOException, ClassNotFoundException;
    String[] onAdidasList() throws SQLException, IOException, ClassNotFoundException;
    String[] onNewBalanceList() throws SQLException, IOException, ClassNotFoundException;
    ArrayList<String> getCatalog() throws SQLException, IOException, ClassNotFoundException;
}