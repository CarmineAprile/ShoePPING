package com.example.shoepping.dao.catalog_dao;

import com.example.shoepping.dao.DaoUtility;
import com.example.shoepping.dao.queries.SimpleQueries;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

public class CatalogDao implements ICatalogDao{

    @Override
    public ArrayList<String> getCatalog() throws SQLException, IOException, ClassNotFoundException {
        Connection conn = DaoUtility.prepareQuery();

        return SimpleQueries.getCatalog(conn);
    }
}
