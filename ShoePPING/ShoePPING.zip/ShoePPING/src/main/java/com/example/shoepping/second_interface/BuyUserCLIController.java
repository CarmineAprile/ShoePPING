package com.example.shoepping.second_interface;

public class BuyUserCLIController {
    public void start() {
        //TODO
    }
}
