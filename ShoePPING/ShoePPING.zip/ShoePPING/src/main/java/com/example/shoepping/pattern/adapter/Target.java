package com.example.shoepping.pattern.adapter;

public interface Target {
    double calculatePrice(String condition, String price);
}
