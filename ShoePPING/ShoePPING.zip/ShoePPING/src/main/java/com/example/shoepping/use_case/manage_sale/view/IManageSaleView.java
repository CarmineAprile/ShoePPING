package com.example.shoepping.use_case.manage_sale.view;

public interface IManageSaleView {
    void setNotAvailableCSV();

    void setSaleButton(String s);
}
