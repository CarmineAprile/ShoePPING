package com.example.shoepping.bean;

public class SellIdUpdateBean {
    private String sellIdUpdate;

    public SellIdUpdateBean() {
        //empty constructor
    }

    public String getSellIdUpdate() {
        return sellIdUpdate;
    }

    public void setSellIdUpdate(String sellIdUpdate) {
        this.sellIdUpdate = sellIdUpdate;
    }
}
