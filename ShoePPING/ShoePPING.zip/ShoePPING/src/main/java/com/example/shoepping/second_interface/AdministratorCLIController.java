package com.example.shoepping.second_interface;

public class AdministratorCLIController {
    public void start() {

        //TODO
    }
}
