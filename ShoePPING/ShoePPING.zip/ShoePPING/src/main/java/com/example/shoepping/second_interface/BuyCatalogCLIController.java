package com.example.shoepping.second_interface;

public class BuyCatalogCLIController {
    public void start() {
        //TODO
    }

}
