package com.example.shoepping.bean;

public class SaleBean {
    private String sale;

    public SaleBean() {
        // empty constructor
    }

    public String getSale() {
        return sale;
    }

    public void setSale(String sale) {
        this.sale = sale;
    }
}
