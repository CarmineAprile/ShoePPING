package com.example.shoepping.bean;

public class CheckedBean {
    boolean isChecked;

    public CheckedBean() {
        // empty constructor
    }

    public boolean getChecked() {
        return isChecked;
    }

    public void setChecked(boolean checked) {
        this.isChecked = checked;
    }
}
