package com.example.shoepping.use_case.administrator.view;

public interface IAdministratorView {

    void onUpdateAmountError();
    void onUpdateAmountSuccess();

    void onUpdatePriceError();
    void onUpdatePriceSuccess();
}
